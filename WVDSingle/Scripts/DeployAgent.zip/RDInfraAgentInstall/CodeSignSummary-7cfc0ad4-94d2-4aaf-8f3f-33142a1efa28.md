 | FileName                  | Status | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|----------|----------------|-------------|-------------|---------------|-------------|
 | taller-x64-1.0.0.1014.msi | Pass   | 17.11MB  | 63.82          | 7.67        | 0.5         | 55.62         | 0           | 
