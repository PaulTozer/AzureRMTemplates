﻿configuration CreateADPDC 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,
        
        [Parameter(Mandatory)]
        [String]$domainDN,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$ADJoinPassword,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    Import-DscResource -ModuleName xActiveDirectory, xStorage, xNetworking, PSDesiredStateConfiguration, xPendingReboot, ActiveDirectoryDsc
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    Node localhost
    {
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }

	    WindowsFeature DNS 
        { 
            Ensure = "Present" 
            Name = "DNS"		
        }

        Script EnableDNSDiags
	    {
      	    SetScript = { 
		        Set-DnsServerDiagnostics -All $true
                Write-Verbose -Verbose "Enabling DNS client diagnostics" 
            }
            GetScript =  { @{} }
            TestScript = { $false }
	        DependsOn = "[WindowsFeature]DNS"
        }

	    WindowsFeature DnsTools
	    {
	        Ensure = "Present"
            Name = "RSAT-DNS-Server"
            DependsOn = "[WindowsFeature]DNS"
	    }

        xDnsServerAddress DnsServerAddress 
        { 
            Address        = '127.0.0.1' 
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
	        DependsOn = "[WindowsFeature]DNS"
        }

        xWaitforDisk Disk2
        {
            DiskNumber = 2
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }

        xDisk ADDataDisk {
            DiskNumber = 2
            DriveLetter = "F"
            DependsOn = "[xWaitForDisk]Disk2"
        }

        WindowsFeature ADDSInstall 
        { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
	        DependsOn="[WindowsFeature]DNS" 
        } 

        WindowsFeature ADDSTools
        {
            Ensure = "Present"
            Name = "RSAT-ADDS-Tools"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }

        WindowsFeature ADAdminCenter
        {
            Ensure = "Present"
            Name = "RSAT-AD-AdminCenter"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }
         
        xADDomain FirstDS 
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "F:\NTDS"
            LogPath = "F:\NTDS"
            SysvolPath = "F:\SYSVOL"
	        DependsOn = @("[xDisk]ADDataDisk", "[WindowsFeature]ADDSInstall")
        } 

        ADReplicationSite 'AzureSquadsSite'
        {
            Ensure                     = 'Present'
            Name                       = 'AzureSquads'
            RenameDefaultFirstSiteName = $true
            DependsOn ='[xADDomain]FirstDS'
        }
        
        ADReplicationSubnet 'AzureSquadsSubnet'
        {
            Name        = '10.0.1.0/24'
            Site        = 'AzureSquads'
            Location    = 'AzureUKSouth'
            Description = 'AzureSquads Subnet'
            DependsOn ='[ADReplicationSite]AzureSquadsSite'
        }

        ADOrganizationalUnit 'azsquads'
        {
            Name                            = "azsquads"
            Path                            = "$domainDN"
            ProtectedFromAccidentalDeletion = $true
            Description                     = "TopLevel OU"
            Ensure                          = 'Present'
        }
		ADOrganizationalUnit 'Admins'
        {
            Name                            = "Admins"
            Path                            = "OU=azsquads,$domainDN"
            ProtectedFromAccidentalDeletion = $true
            Description                     = "Administration OU"
			Ensure                          = 'Present'
			DependsOn 						= "[ADOrganizationalUnit]azsquads"
		}
		ADOrganizationalUnit 'AVDhosts'
        {
            Name                            = "AVDhosts"
            Path                            = "OU=azsquads,$domainDN"
            ProtectedFromAccidentalDeletion = $true
            Description                     = "AVD Session Hosts OU"
			Ensure                          = 'Present'
			DependsOn 						= "[ADOrganizationalUnit]azsquads"
		}
		ADOrganizationalUnit 'Servers'
        {
            Name                            = "Servers"
            Path                            = "OU=azsquads,$domainDN"
            ProtectedFromAccidentalDeletion = $true
            Description                     = "Servers OU"
			Ensure                          = 'Present'
			DependsOn 						= "[ADOrganizationalUnit]azsquads"
		}
        ADOrganizationalUnit 'ServiceAccounts'
        {
            Name                            = "ServiceAccounts"
            Path                            = "OU=azsquads,$domainDN"
            ProtectedFromAccidentalDeletion = $true
            Description                     = "Service Accounts OU"
			Ensure                          = 'Present'
			DependsOn 						= "[ADOrganizationalUnit]azsquads"
		}
        ADUser 'azsquads\AVDComputerJoin'
        {
            Ensure  = "Present"
            UserName   = "AVDComputerJoin"
            Password   = $ADJoinPassword
            DomainName = $DomainName
            Path     = "OU=ServiceAccounts,OU=azsquads,$domainDN"
            DependsOn 						="[ADOrganizationalUnit]ServiceAccounts"
        }
        ADOrganizationalUnit 'Users'
        {
            Name                            = "Users"
            Path                            = "OU=azsquads,$domainDN"
            ProtectedFromAccidentalDeletion = $true
            Description                     = "Service Accounts OU"
			Ensure                          = 'Present'
			DependsOn 						= "[ADOrganizationalUnit]azsquads"
		}
		ADOrganizationalUnit 'Personal'
        {
            Name                            = "Personal"
            Path                            = "OU=AVDHosts,OU=azsquads,$domainDN"
            ProtectedFromAccidentalDeletion = $true
            Description                     = "Personal Pool OU"
			Ensure                          = 'Present'
			DependsOn 						= "[ADOrganizationalUnit]AVDhosts"
		}
		ADOrganizationalUnit 'Pooled'
        {
            Name                            = "Pooled"
            Path                            = "OU=AVDHosts,OU=azsquads,$domainDN"
            ProtectedFromAccidentalDeletion = $true
            Description                     = "Pooled Pool OU"
			Ensure                          = 'Present'
			DependsOn 						= "[ADOrganizationalUnit]AVDhosts"
		}
		ADOrganizationalUnit 'PersonalAZFiles'
        {
            Name                            = "AzFiles"
            Path                            = "OU=Personal,OU=AVDHosts,OU=azsquads,$domainDN"
            ProtectedFromAccidentalDeletion = $true
            Description                     = "AZ Files Personal Pool OU"
			Ensure                          = 'Present'
			DependsOn 						= "[ADOrganizationalUnit]Personal"
		}
        ADOrganizationalUnit 'PooledAZFiles'
        {
            Name                            = "AzFiles"
            Path                            = "OU=Pooled,OU=AVDHosts,OU=azsquads,$domainDN"
            ProtectedFromAccidentalDeletion = $true
            Description                     = "AZ Files Pooled Pool OU"
			Ensure                          = 'Present'
			DependsOn 						= "[ADOrganizationalUnit]Pooled"
		}
        ADOrganizationalUnit 'PersonalNetApp'
        {
            Name                            = "NetApp"
            Path                            = "OU=Personal,OU=AVDHosts,OU=azsquads,$domainDN"
            ProtectedFromAccidentalDeletion = $true
            Description                     = "NetApp Files Personal Pool OU"
			Ensure                          = 'Present'
			DependsOn 						= "[ADOrganizationalUnit]Personal"
		}
        ADOrganizationalUnit 'PooledNetApp'
        {
            Name                            = "NetApp"
            Path                            = "OU=Pooled,OU=AVDHosts,OU=azsquads,$domainDN"
            ProtectedFromAccidentalDeletion = $true
            Description                     = "NetApp Files Pooled Pool OU"
			Ensure                          = 'Present'
			DependsOn 						= "[ADOrganizationalUnit]Pooled"
		}
        ADObjectPermissionEntry 'ADObjectPermissionEntryPersonal'
        {
            Ensure                             = 'Present'
            Path                               = "OU=Pooled,OU=AVDHosts,OU=azsquads,$domainDN"
            IdentityReference                  = "$DomainName\AVDComputerJoin"
            ActiveDirectoryRights              = 'CreateChild', 'DeleteChild'
            AccessControlType                  = 'Allow'
            ObjectType                         = 'bf967a86-0de6-11d0-a285-00aa003049e2' # Computer objects
            ActiveDirectorySecurityInheritance = 'All'
            InheritedObjectType                = '00000000-0000-0000-0000-000000000000'
        }
        ADObjectPermissionEntry 'ADObjectPermissionEntryPooled'
        {
            Ensure                             = 'Present'
            Path                               = "OU=Pooled,OU=AVDHosts,OU=azsquads,$domainDN"
            IdentityReference                  = "$DomainName\AVDComputerJoin"
            ActiveDirectoryRights              = 'CreateChild', 'DeleteChild'
            AccessControlType                  = 'Allow'
            ObjectType                         = 'bf967a86-0de6-11d0-a285-00aa003049e2' # Computer objects
            ActiveDirectorySecurityInheritance = 'All'
            InheritedObjectType                = '00000000-0000-0000-0000-000000000000'
        }

   }
} 